<template>
  <DashboardLayout>
    <div class="min-h-screen bg-gray-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          <!-- Left Side - Main Content -->
          <div class="lg:col-span-2 space-y-6">
            
            <!-- Header Card -->
            <div class="relative overflow-hidden bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-3xl shadow-2xl p-8 text-white">
              <!-- Decorative Elements -->
              <div class="absolute top-0 right-0 w-64 h-64 bg-white opacity-10 rounded-full -mr-32 -mt-32"></div>
              <div class="absolute bottom-0 left-0 w-48 h-48 bg-white opacity-10 rounded-full -ml-24 -mb-24"></div>
              
              <div class="relative z-10">
                <div class="flex items-center gap-3 mb-3">
                  <div class="w-14 h-14 bg-yellow-500 rounded-full flex items-center justify-center text-3xl shadow-lg">
                    🏆
                  </div>
                  <div>
                    <h1 class="text-3xl md:text-4xl font-bold">Community Heroes</h1>
                    <p class="text-purple-200 text-sm">Hall of Fame</p>
                  </div>
                </div>
                
                <p class="text-purple-100 mb-6 text-sm md:text-base">
                  Celebrating our amazing community members who help reunite lost items!
                </p>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div class="bg-blue-700 bg-opacity-20 backdrop-blur-md rounded-2xl p-4 hover:bg-opacity-30 transition">
                    <div class="flex items-center gap-2 mb-2">
                      <svg class="w-5 h-5 text-yellow-300" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                      </svg>
                      <div class="text-2xl font-bold text-white">{{ totalReturned }}</div>
                    </div>
                    <div class="text-xs text-white font-semibold">Items Returned</div>
                  </div>
                  
                  <div class="bg-blue-700 bg-opacity-20 backdrop-blur-md rounded-2xl p-4 hover:bg-opacity-30 transition">
                    <div class="flex items-center gap-2 mb-2">
                      <svg class="w-5 h-5 text-green-300" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z"/>
                      </svg>
                      <div class="text-2xl font-bold text-white">{{ totalUsers }}</div>
                    </div>
                    <div class="text-xs text-white font-semibold">Active Heroes</div>
                  </div>
                  
                  <div class="bg-blue-700 bg-opacity-20 backdrop-blur-md rounded-2xl p-4 hover:bg-opacity-30 transition">
                    <div class="flex items-center gap-2 mb-2">
                      <svg class="w-5 h-5 text-blue-300" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                      </svg>
                      <div class="text-2xl font-bold text-white">{{ successRate }}%</div>
                    </div>
                    <div class="text-xs text-white font-semibold">Success Rate</div>
                  </div>
                  
                  <div class="bg-blue-700 bg-opacity-20 backdrop-blur-md rounded-2xl p-4 hover:bg-opacity-30 transition">
                    <div class="flex items-center gap-2 mb-2">
                      <svg class="w-5 h-5 text-pink-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/>
                      </svg>
                      <div class="text-2xl font-bold text-white">{{ totalPoints }}</div>
                    </div>
                    <div class="text-xs text-white font-semibold">Total Points</div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Top 3 Winners -->
            <div class="bg-white rounded-2xl shadow-lg p-4 md:p-6">
              <div class="flex items-center justify-between mb-4 md:mb-6">
                <h2 class="text-xl md:text-2xl font-bold text-gray-900">Top Champions</h2>
                <span class="text-xs md:text-sm text-gray-500">This Month</span>
              </div>

              <div class="grid grid-cols-3 gap-2 md:gap-4">
                <!-- Winner Cards -->
                <div 
                  v-for="(winner, index) in topThree" 
                  :key="index"
                  class="relative bg-gradient-to-br rounded-lg md:rounded-xl p-3 md:p-6 text-center transform hover:scale-105 transition-transform cursor-pointer"
                  :class="winner.gradient"
                >
                  <!-- Rank Badge -->
                  <div class="absolute -top-2 -right-2 w-8 h-8 md:w-12 md:h-12 rounded-full flex items-center justify-center text-sm md:text-xl font-bold shadow-lg"
                    :class="winner.badgeColor">
                    {{ winner.rank }}
                  </div>

                  <!-- Avatar -->
                  <div class="relative w-12 h-12 md:w-20 md:h-20 mx-auto mb-2 md:mb-4">
                    <div class="w-full h-full rounded-full bg-white flex items-center justify-center text-lg md:text-2xl font-bold shadow-lg"
                      :class="winner.avatarText">
                      {{ winner.name.charAt(0) }}
                    </div>
                    <div v-if="winner.rank === 1" class="absolute -top-1 -right-1 md:-top-2 md:-right-2 text-xl md:text-3xl">👑</div>
                  </div>

                  <h3 class="font-bold text-gray-900 mb-1 text-xs md:text-base truncate">{{ winner.name }}</h3>
                  <p class="text-[10px] md:text-xs text-gray-600 mb-2 md:mb-3 truncate">{{ winner.studentId }}</p>
                  
                  <div class="flex items-center justify-center gap-1 md:gap-2 mb-1 md:mb-2">
                    <svg class="w-3 h-3 md:w-5 md:h-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                    </svg>
                    <span class="font-bold text-gray-900 text-sm md:text-base">{{ winner.points }}</span>
                  </div>
                  
                  <div class="text-[10px] md:text-xs text-gray-600">{{ winner.itemsFound }} items</div>
                </div>
              </div>
            </div>

          </div>

          <!-- Right Side - Leaderboard List -->
          <div class="lg:col-span-1">
            <div class="bg-white rounded-2xl shadow-lg overflow-hidden sticky top-6">
              <div class="bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white">
                <h2 class="text-xl font-bold mb-1">Leaderboard</h2>
                <p class="text-sm text-blue-100">All Time Rankings</p>
              </div>

              <div class="p-4 max-h-[600px] overflow-y-auto">
                <div 
                    v-for="(user, index) in rankingsWithStyle" 
                    :key="index"
                    class="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition cursor-pointer mb-2"
                    :class="{ 'bg-blue-50': user.isCurrentUser }"
                    >
                  <!-- Rank -->
                  <div class="flex-shrink-0 w-8 text-center">
                    <span class="font-bold text-gray-900">#{{ user.rank }}</span>
                  </div>

                  <!-- Avatar -->
                  <div class="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br flex items-center justify-center text-white font-semibold shadow-md"
                    :class="user.avatarGradient">
                    {{ user.name.charAt(0) }}
                  </div>

                  <!-- User Info -->
                  <div class="flex-1 min-w-0">
                    <div class="font-semibold text-gray-900 truncate">{{ user.name }}</div>
                    <div class="text-xs text-gray-500">{{ user.points }} points</div>
                  </div>

                  <!-- Like/Points Icon -->
                  <div class="flex-shrink-0">
                    <svg v-if="user.isCurrentUser" class="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                    </svg>
                    <svg v-else class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        <!-- How Points Work Section -->
        <div class="mt-8 bg-white rounded-2xl shadow-lg p-6">
          <h3 class="text-xl font-bold text-gray-900 mb-4">🎯 How to Earn Points</h3>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="flex items-start gap-3 p-4 bg-green-50 rounded-xl">
              <div class="flex-shrink-0 w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
              </div>
              <div>
                <div class="font-semibold text-gray-900 mb-1">Report Found Item</div>
                <div class="text-sm text-gray-600">+10 points per item</div>
              </div>
            </div>

            <div class="flex items-start gap-3 p-4 bg-blue-50 rounded-xl">
              <div class="flex-shrink-0 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                </svg>
              </div>
              <div>
                <div class="font-semibold text-gray-900 mb-1">Successful Match</div>
                <div class="text-sm text-gray-600">+25 bonus points</div>
              </div>
            </div>

            <div class="flex items-start gap-3 p-4 bg-purple-50 rounded-xl">
              <div class="flex-shrink-0 w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"/>
                </svg>
              </div>
              <div>
                <div class="font-semibold text-gray-900 mb-1">Item Returned</div>
                <div class="text-sm text-gray-600">+50 points when claimed</div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useToast } from 'vue-toastification'
import DashboardLayout from '../layouts/DashboardLayout.vue'
import RankingService from '../services/ranking.service'
import AuthService from '../services/auth.service'
import type { RankingEntry } from '../types/api.types'

const router = useRouter()
const toast = useToast()

// User info
const currentUserId = ref<number | null>(null)

// Stats
const totalReturned = ref(0)
const totalUsers = ref(0)
const successRate = ref(95)
const totalPoints = ref(0)

// Rankings data
const allRankings = ref<RankingEntry[]>([])
const isLoading = ref(false)

// Avatar gradient colors for variety
const gradientColors = [
  'from-yellow-400 to-orange-500',
  'from-blue-400 to-blue-600',
  'from-purple-400 to-purple-600',
  'from-green-400 to-green-600',
  'from-pink-400 to-pink-600',
  'from-indigo-400 to-indigo-600',
  'from-red-400 to-red-600',
  'from-teal-400 to-teal-600',
  'from-cyan-400 to-cyan-600',
  'from-orange-400 to-orange-600',
  'from-lime-400 to-lime-600',
  'from-emerald-400 to-emerald-600',
  'from-violet-400 to-violet-600',
  'from-fuchsia-400 to-fuchsia-600',
]

// Get gradient color for a user (consistent based on index)
const getGradient = (index: number): string => {
  return gradientColors[index % gradientColors.length] || 'from-blue-400 to-blue-600'
}

// Top 3 with special styling
const topThree = computed(() => {
  const top3 = allRankings.value.slice(0, 3)
  return top3.map((entry, index) => {
    let gradient = ''
    let badgeColor = ''
    let avatarText = ''
    
    if (entry.rank === 1) {
      gradient = 'from-yellow-400 to-orange-500'
      badgeColor = 'bg-yellow-400 text-yellow-900'
      avatarText = 'text-yellow-600'
    } else if (entry.rank === 2) {
      gradient = 'from-gray-300 to-gray-400'
      badgeColor = 'bg-gray-300 text-gray-900'
      avatarText = 'text-gray-600'
    } else if (entry.rank === 3) {
      gradient = 'from-orange-400 to-red-500'
      badgeColor = 'bg-orange-400 text-orange-900'
      avatarText = 'text-orange-600'
    }
    
    return {
      rank: entry.rank,
      name: entry.fullName,
      studentId: `User ${entry.userId}`, // You can format this better if you have student ID
      points: entry.points,
      itemsFound: entry.itemsFound,
      gradient,
      badgeColor,
      avatarText
    }
  })
})

// All rankings with avatar gradients and current user highlight
const rankingsWithStyle = computed(() => {
  return allRankings.value.map((entry, index) => {
    return {
      rank: entry.rank,
      name: entry.fullName,
      points: entry.points,
      avatarGradient: entry.userId === currentUserId.value 
        ? 'from-blue-500 to-blue-700'  // Special color for current user
        : getGradient(index),
      isCurrentUser: entry.userId === currentUserId.value
    }
  })
})

// Load leaderboard data
const loadLeaderboard = async () => {
  console.log('=== LOADING LEADERBOARD ===')
  isLoading.value = true
  
  try {
    // Get current user ID
    currentUserId.value = AuthService.getUserId()
    console.log('Current user ID:', currentUserId.value)
    
    // Fetch leaderboard from backend
    console.log('Fetching leaderboard from /api/user/leaderboard...')
    const rankings = await RankingService.getLeaderboard()
    console.log('Leaderboard received:', rankings)
    console.log('Number of users:', rankings.length)
    console.log('First user:', rankings[0])
    
    allRankings.value = rankings
    
    // Calculate stats from leaderboard
    totalUsers.value = rankings.length
    totalPoints.value = rankings.reduce((sum, entry) => sum + entry.points, 0)
    totalReturned.value = rankings.reduce((sum, entry) => sum + entry.itemsReturned, 0)
    
    console.log('Stats calculated:', {
      totalUsers: totalUsers.value,
      totalPoints: totalPoints.value,
      totalReturned: totalReturned.value
    })
    
    console.log('allRankings set to:', allRankings.value)
    console.log('rankingsWithStyle computed:', rankingsWithStyle.value)
    
    // If no rankings, show message
    if (rankings.length === 0) {
      console.warn('No rankings data received!')
      toast.info('No rankings yet. Be the first to help!')
    }
    
  } catch (error: any) {
    console.error('=== ERROR LOADING LEADERBOARD ===')
    console.error('Error:', error)
    console.error('Error message:', error.message)
    console.error('Error response:', error.response)
    
    toast.error('Failed to load leaderboard')
    
    // Show empty state
    allRankings.value = []
  } finally {
    isLoading.value = false
    console.log('=== LOADING COMPLETE ===')
  }
}

// Load community stats
const loadCommunityStats = async () => {
  try {
    console.log('Fetching community stats from /api/user/community-stats...')
    const response = await fetch('http://localhost:8080/api/user/community-stats')
    const data = await response.json()
    console.log('Community stats received:', data)
    
    // Update stats with real data
    totalReturned.value = data.totalItemsReturned || 0
    totalUsers.value = data.totalUsers || 0
    successRate.value = data.successRate || 0
    totalPoints.value = data.totalPoints || 0
    
    console.log('Community stats updated:', {
      totalReturned: totalReturned.value,
      totalUsers: totalUsers.value,
      successRate: successRate.value,
      totalPoints: totalPoints.value
    })
  } catch (error: any) {
    console.error('Error loading community stats:', error)
    // Keep default values if error
  }
}

// Get initials from name for avatar
const getInitials = (name: string): string => {
  const parts = name.split(' ')
  if (parts.length >= 2 && parts[0] && parts[1]) {
    return (parts[0][0] + parts[1][0]).toUpperCase()
  }
  return name.substring(0, 2).toUpperCase()
}

// Load data on mount
onMounted(async () => {
  // Check if user is logged in
  if (!AuthService.isAuthenticated()) {
    toast.error('Please login first')
    router.push('/login')
    return
  }
  
  // Load both leaderboard and community stats
  await Promise.all([
    loadLeaderboard(),
    loadCommunityStats()
  ])
})
</script>
